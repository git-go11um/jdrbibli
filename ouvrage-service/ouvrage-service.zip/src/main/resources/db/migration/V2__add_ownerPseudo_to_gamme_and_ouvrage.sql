/* ALTER TABLE gammes
ADD COLUMN owner_pseudo VARCHAR(255) NOT NULL DEFAULT 'admin';

ALTER TABLE ouvrages
ADD COLUMN owner_pseudo VARCHAR(255) NOT NULL DEFAULT 'admin'; */